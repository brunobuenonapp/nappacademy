name = input("Digite seu nome: ")
age = int(input("Digite sua idade: "))

newage = age + 5

print("Seu nome é: ",name )
print("Sua idade daqui a cinco anos será: ",newage)
