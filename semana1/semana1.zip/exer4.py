lista_nomes = ['Ana', 'Ana Maria', 'Pedro', 'Elena', 'Helena', 'Elen']

for nome in lista_nomes:
        print(nome.replace('', ' | '))